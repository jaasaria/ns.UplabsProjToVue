module.exports = require("kinvey-nativescript-sdk/lib/before-preview-sync.js");
