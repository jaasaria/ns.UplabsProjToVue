/**
 * Force change the orientation
 * @param orientationType
 * @param callback
 */
export function setCurrentOrientation(orientationType:string,callback:any):void;


/**
 * allow rotation
 */
export function orientationCleanup():void;