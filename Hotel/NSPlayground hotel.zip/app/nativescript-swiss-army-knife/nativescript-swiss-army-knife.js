"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var app = require("tns-core-modules/application");
var color_1 = require("tns-core-modules/color");
var platform_1 = require("tns-core-modules/platform");
var frame_1 = require("tns-core-modules/ui/frame");
var SwissArmyKnife = (function () {
    function SwissArmyKnife() {
    }
    Object.defineProperty(SwissArmyKnife.prototype, "android", {
        get: function () {
            return;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SwissArmyKnife.prototype, "ios", {
        get: function () {
            return;
        },
        enumerable: true,
        configurable: true
    });
    SwissArmyKnife.disableScrollBounce = function (view) {
        if (platform_1.isIOS) {
            view.ios.bounces = false;
        }
        else if (platform_1.isAndroid && view.android != null) {
            view.android.setOverScrollMode(2);
        }
    };
    SwissArmyKnife.removeHorizontalScrollBars = function (view) {
        if (platform_1.isIOS) {
            view.ios.showsHorizontalScrollIndicator = false;
        }
        else {
            view.android.setHorizontalScrollBarEnabled(false);
        }
    };
    SwissArmyKnife.removeVerticalScrollBars = function (view) {
        if (platform_1.isIOS) {
            view.ios.showsVerticalScrollIndicator = false;
        }
        else {
            view.android.setVerticalScrollBarEnabled(false);
        }
    };
    SwissArmyKnife.pluckChildViewsFromLayout = function (parent) {
        var returnViews = [];
        parent.eachLayoutChild(function (child) {
            returnViews.push(child);
        });
        parent.removeChildren();
        return returnViews;
    };
    SwissArmyKnife.getScreenHeight = function () {
        var height1 = platform_1.screen.mainScreen.heightDIPs;
        var height2 = platform_1.screen.mainScreen.widthDIPs;
        var statusbar = this._getStatusBarHeight();
        var navbar = this._getNavBarHeight();
        return {
            portrait: height1,
            landscape: height2,
            androidStatusBar: statusbar,
            androidNavBar: navbar
        };
    };
    SwissArmyKnife.actionBarSetTitle = function (title) {
        var actionBar = frame_1.topmost().currentPage.actionBar;
        actionBar.title = title;
    };
    SwissArmyKnife.actionBarAddButton = function (button) {
        frame_1.topmost().currentPage.actionBar.actionItems.addItem(button);
    };
    SwissArmyKnife.actionBarClearButtons = function () {
        var actionBar = frame_1.topmost().currentPage.actionBar;
        var actionItems = actionBar.actionItems.getItems();
        actionItems.forEach(function (item) {
            actionBar.actionItems.removeItem(item);
        });
    };
    SwissArmyKnife.setAndroidStatusBarTranslucentFlag = function () {
        if (platform_1.isAndroid && platform_1.device.sdkVersion >= "19") {
            var LayoutParams = android.view.WindowManager.LayoutParams;
            var window_1 = this._androidActivity.getWindow();
            window_1.addFlags(LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    };
    SwissArmyKnife.resetAndroidStatusBarTranslucentFlag = function () {
        if (platform_1.isAndroid && platform_1.device.sdkVersion >= "19") {
            var window_2 = this._androidActivity.getWindow();
            var LayoutParams = android.view.WindowManager.LayoutParams;
            window_2.clearFlags(LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    };
    SwissArmyKnife.setAndroidNavBarTranslucentFlag = function () {
        if (platform_1.isAndroid && platform_1.device.sdkVersion >= "19") {
            var window_3 = this._androidActivity.getWindow();
            var LayoutParams = android.view.WindowManager.LayoutParams;
            window_3.addFlags(LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
    };
    SwissArmyKnife.resetAndroidNavBarTranslucentFlag = function () {
        if (platform_1.isAndroid && platform_1.device.sdkVersion >= "19") {
            var window_4 = this._androidActivity.getWindow();
            var LayoutParams = android.view.WindowManager.LayoutParams;
            window_4.clearFlags(LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
    };
    SwissArmyKnife.setAndroidStatusBarColor = function (color) {
        if (platform_1.isAndroid && platform_1.device.sdkVersion >= "21") {
            var barColor = this._getBarColor(color);
            var LayoutParams = android.view.WindowManager.LayoutParams;
            var window_5;
            if (this._androidActivity != null) {
                window_5 = this._androidActivity.getWindow();
            }
            else {
                window_5 = this._androidActivity.getWindow();
            }
            window_5.addFlags(LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window_5.setStatusBarColor(barColor.android);
        }
    };
    SwissArmyKnife.setAndroidNavBarColor = function (color) {
        if (platform_1.isAndroid && platform_1.device.sdkVersion >= "21") {
            var barColor = this._getBarColor(color);
            var LayoutParams = android.view.WindowManager.LayoutParams;
            var window_6;
            if (this._androidActivity != null) {
                window_6 = this._androidActivity.getWindow();
            }
            else {
                window_6 = this._androidActivity.getWindow();
            }
            window_6.addFlags(LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window_6.setNavigationBarColor(barColor.android);
        }
    };
    SwissArmyKnife.actionBarHideBackButton = function () {
        if (frame_1.topmost().ios) {
            frame_1.topmost().ios.controller.visibleViewController.navigationItem.setHidesBackButtonAnimated(true, false);
        }
    };
    SwissArmyKnife.actionBarSetStatusBarStyle = function (style) {
        if (frame_1.topmost().ios) {
            var navigationBar = frame_1.topmost().ios.controller.navigationBar;
            navigationBar.barStyle = style;
        }
    };
    SwissArmyKnife.dismissSoftKeyboard = function () {
        if (platform_1.isAndroid) {
            var inputManager = this._androidContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
            var currentFocus = this._androidActivity.getCurrentFocus();
            if (currentFocus) {
                var windowToken = currentFocus.getWindowToken();
                if (windowToken) {
                    inputManager.hideSoftInputFromWindow(windowToken, android.view.inputmethod.InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        }
        else if (platform_1.isIOS) {
            UIApplication.sharedApplication.sendActionToFromForEvent("resignFirstResponder", null, null, null);
        }
    };
    SwissArmyKnife._getStatusBarHeight = function () {
        if (platform_1.isAndroid) {
            var result = 0;
            var resourceId = this._androidContext
                .getResources()
                .getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                result = this._androidContext
                    .getResources()
                    .getDimensionPixelSize(resourceId);
                result =
                    result /
                        this._androidContext.getResources().getDisplayMetrics().density;
            }
            return result;
        }
        else {
            return 0;
        }
    };
    SwissArmyKnife._getBarColor = function (color) {
        var barColor;
        if (color instanceof color_1.Color === false) {
            barColor = new color_1.Color(color);
        }
        else {
            barColor = color;
        }
        return barColor;
    };
    SwissArmyKnife._getNavBarHeight = function () {
        if (platform_1.isAndroid) {
            var result = 0;
            var resourceId = this._androidContext
                .getResources()
                .getIdentifier("navigation_bar_height", "dimen", "android");
            if (resourceId > 0) {
                result = this._androidContext
                    .getResources()
                    .getDimensionPixelSize(resourceId);
                result =
                    result /
                        this._androidContext.getResources().getDisplayMetrics().density;
            }
            return result;
        }
        else {
            return 0;
        }
    };
    Object.defineProperty(SwissArmyKnife, "_androidContext", {
        get: function () {
            return app.android.context || app.android.currentContext;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SwissArmyKnife, "_androidActivity", {
        get: function () {
            return app.android.foregroundActivity || app.android.startActivity;
        },
        enumerable: true,
        configurable: true
    });
    return SwissArmyKnife;
}());
exports.SwissArmyKnife = SwissArmyKnife;
