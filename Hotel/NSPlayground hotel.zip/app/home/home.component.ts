import { Component, OnInit } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { Page } from "tns-core-modules/ui/page";
import { View } from "ui/core/view";
import { StackLayout } from "ui/layouts/stack-layout";
import { ViewBase } from "ui/core/view-base";
import { ScrollView } from "tns-core-modules/ui/scroll-view";
import { RouterExtensions } from "nativescript-angular/router";
import { topmost } from "ui/frame";
import { SwissArmyKnife } from "../nativescript-swiss-army-knife";

@Component({
    selector: "Home",
    moduleId: module.id,
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    constructor(private routerExtensions: RouterExtensions) {
    }

    ngOnInit(): void {

    }

    ngAfterViewInit(): void {
        console.log('Removing horizontal scrollbars')
        topmost().eachChild((view: ViewBase): boolean => {
            console.log(view.typeName)
            if (view.typeName === 'ScrollView') {
                const scrollView = <ScrollView>view;
                if (scrollView.orientation === 'horizontal') {
                    SwissArmyKnife.removeHorizontalScrollBars(<ScrollView>view)
                }
            }
            return true
        })
    }

    disableScrollBar(args: EventData): void {
        console.log('Disabling scroll bar')
        console.log(args.object)
        SwissArmyKnife.removeHorizontalScrollBars(<ScrollView>args.object)
    }
}
