import { Component, OnInit } from "@angular/core";
import { Page } from "tns-core-modules/ui/page";
import { RouterExtensions } from "nativescript-angular/router";
import { setCurrentOrientation, orientationCleanup } from '../nativescript-screen-orientation';


@Component({
    selector: "Room",
    moduleId: module.id,
    templateUrl: "./room.component.html",
    styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {
    bookmarked: Boolean;

    constructor(private page: Page, private routerExtensions: RouterExtensions) {
        this.bookmarked = false;
        setCurrentOrientation("portrait", function () {
            console.log("portrait orientation");
        });
        page.on("navigatingFrom", function () {
            orientationCleanup();
        });
    }

    ngOnInit(): void {
        this.page.actionBarHidden = true;
    }

    public goBack() {
        this.routerExtensions.back();
    }

    public toggleBookmark() {
        this.bookmarked = !this.bookmarked;
    }
}
