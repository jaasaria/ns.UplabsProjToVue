module.exports = require("kinvey-nativescript-sdk/lib/before-checkForChanges.js");
