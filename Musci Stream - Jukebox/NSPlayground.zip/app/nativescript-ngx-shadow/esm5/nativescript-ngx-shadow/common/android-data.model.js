/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var AndroidData = /** @class */ (function () {
    function AndroidData() {
    }
    return AndroidData;
}());
export { AndroidData };
function AndroidData_tsickle_Closure_declarations() {
    /** @type {?} */
    AndroidData.prototype.elevation;
    /** @type {?} */
    AndroidData.prototype.pressedElevation;
    /** @type {?} */
    AndroidData.prototype.shape;
    /** @type {?} */
    AndroidData.prototype.bgcolor;
    /** @type {?} */
    AndroidData.prototype.cornerRadius;
    /** @type {?} */
    AndroidData.prototype.translationZ;
    /** @type {?} */
    AndroidData.prototype.pressedTranslationZ;
    /** @type {?} */
    AndroidData.prototype.forcePressAnimation;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5kcm9pZC1kYXRhLm1vZGVsLmpzIiwic291cmNlUm9vdCI6Im5nOi8vbmF0aXZlc2NyaXB0LW5neC1zaGFkb3cvIiwic291cmNlcyI6WyJuYXRpdmVzY3JpcHQtbmd4LXNoYWRvdy9jb21tb24vYW5kcm9pZC1kYXRhLm1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFFQSxJQUFBOzs7c0JBRkE7SUFXQyxDQUFBO0FBVEQsdUJBU0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTaGFwZSB9IGZyb20gJy4vc2hhcGUuZW51bSc7XG5cbmV4cG9ydCBjbGFzcyBBbmRyb2lkRGF0YSB7XG4gIGVsZXZhdGlvbjogbnVtYmVyO1xuICBwcmVzc2VkRWxldmF0aW9uPzogbnVtYmVyO1xuICBzaGFwZT86IFNoYXBlO1xuICBiZ2NvbG9yPzogc3RyaW5nO1xuICBjb3JuZXJSYWRpdXM/OiBudW1iZXI7XG4gIHRyYW5zbGF0aW9uWj86IG51bWJlcjtcbiAgcHJlc3NlZFRyYW5zbGF0aW9uWj86IG51bWJlcjtcbiAgZm9yY2VQcmVzc0FuaW1hdGlvbj86IGJvb2xlYW47XG59XG4iXX0=