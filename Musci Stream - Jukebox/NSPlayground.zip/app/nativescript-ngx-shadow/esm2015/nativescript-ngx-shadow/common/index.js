/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
export { AndroidData } from './android-data.model';
export { Elevation } from './elevation.enum';
export { IOSData } from './ios-data.model';
export { Shadow } from './shadow';
export { ShapeEnum } from './shape.enum';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uYXRpdmVzY3JpcHQtbmd4LXNoYWRvdy8iLCJzb3VyY2VzIjpbIm5hdGl2ZXNjcmlwdC1uZ3gtc2hhZG93L2NvbW1vbi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsNEJBQWMsc0JBQXNCLENBQUM7QUFDckMsMEJBQWMsa0JBQWtCLENBQUM7QUFDakMsd0JBQWMsa0JBQWtCLENBQUM7QUFDakMsdUJBQWMsVUFBVSxDQUFDO0FBQ3pCLDBCQUFjLGNBQWMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCAqIGZyb20gJy4vYW5kcm9pZC1kYXRhLm1vZGVsJztcbmV4cG9ydCAqIGZyb20gJy4vZWxldmF0aW9uLmVudW0nO1xuZXhwb3J0ICogZnJvbSAnLi9pb3MtZGF0YS5tb2RlbCc7XG5leHBvcnQgKiBmcm9tICcuL3NoYWRvdyc7XG5leHBvcnQgKiBmcm9tICcuL3NoYXBlLmVudW0nOyJdfQ==