/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
export class IOSData {
}
function IOSData_tsickle_Closure_declarations() {
    /** @type {?} */
    IOSData.prototype.elevation;
    /** @type {?} */
    IOSData.prototype.maskToBounds;
    /** @type {?} */
    IOSData.prototype.shadowColor;
    /** @type {?} */
    IOSData.prototype.shadowOffset;
    /** @type {?} */
    IOSData.prototype.shadowOpacity;
    /** @type {?} */
    IOSData.prototype.shadowRadius;
    /** @type {?} */
    IOSData.prototype.rasterize;
    /** @type {?} */
    IOSData.prototype.useShadowPath;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW9zLWRhdGEubW9kZWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uYXRpdmVzY3JpcHQtbmd4LXNoYWRvdy8iLCJzb3VyY2VzIjpbIm5hdGl2ZXNjcmlwdC1uZ3gtc2hhZG93L2NvbW1vbi9pb3MtZGF0YS5tb2RlbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsTUFBTTtDQVNMIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIElPU0RhdGEge1xuICBlbGV2YXRpb246IG51bWJlcjtcbiAgbWFza1RvQm91bmRzPzogYm9vbGVhbjtcbiAgc2hhZG93Q29sb3I/OiBzdHJpbmc7XG4gIHNoYWRvd09mZnNldD86IG51bWJlcjtcbiAgc2hhZG93T3BhY2l0eT86IG51bWJlcjtcbiAgc2hhZG93UmFkaXVzPzogbnVtYmVyO1xuICByYXN0ZXJpemU/OiBib29sZWFuO1xuICB1c2VTaGFkb3dQYXRoPzogYm9vbGVhbjtcbn1cbiJdfQ==