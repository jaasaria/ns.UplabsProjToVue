/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/** @enum {string} */
const ShapeEnum = {
    RECTANGLE: 'RECTANGLE',
    OVAL: 'OVAL',
    RING: 'RING',
    LINE: 'LINE',
};
export { ShapeEnum };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hhcGUuZW51bS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25hdGl2ZXNjcmlwdC1uZ3gtc2hhZG93LyIsInNvdXJjZXMiOlsibmF0aXZlc2NyaXB0LW5neC1zaGFkb3cvY29tbW9uL3NoYXBlLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O2VBRWMsV0FBVztVQUNoQixNQUFNO1VBQ04sTUFBTTtVQUNOLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCBlbnVtIFNoYXBlRW51bSB7XG4gIFJFQ1RBTkdMRSA9ICdSRUNUQU5HTEUnLFxuICBPVkFMID0gJ09WQUwnLFxuICBSSU5HID0gJ1JJTkcnLFxuICBMSU5FID0gJ0xJTkUnLFxufVxuXG5leHBvcnQgdHlwZSBTaGFwZSA9ICdSRUNUQU5HTEUnIHwgJ09WQUwnIHwgJ1JJTkcnIHwgJ0xJTkUnO1xuIl19