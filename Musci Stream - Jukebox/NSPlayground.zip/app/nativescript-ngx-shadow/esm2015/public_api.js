/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
export { NgShadowModule } from './lib.module';
export { AndroidData, Elevation, IOSData, Shadow, ShapeEnum } from './nativescript-ngx-shadow/common';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25hdGl2ZXNjcmlwdC1uZ3gtc2hhZG93LyIsInNvdXJjZXMiOlsicHVibGljX2FwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsK0JBQWMsY0FBYyxDQUFDO0FBQzdCLG1FQUFjLGtDQUFrQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0ICogZnJvbSAnLi9saWIubW9kdWxlJztcbmV4cG9ydCAqIGZyb20gJy4vbmF0aXZlc2NyaXB0LW5neC1zaGFkb3cvY29tbW9uJzsiXX0=