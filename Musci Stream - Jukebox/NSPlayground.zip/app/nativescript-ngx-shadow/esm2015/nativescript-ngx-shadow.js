/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { NgShadowModule, AndroidData, Elevation, IOSData, Shadow, ShapeEnum } from './public_api';
export { NativeShadowDirective as ɵa } from './nativescript-ngx-shadow/ng-shadow.directive';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmF0aXZlc2NyaXB0LW5neC1zaGFkb3cuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uYXRpdmVzY3JpcHQtbmd4LXNoYWRvdy8iLCJzb3VyY2VzIjpbIm5hdGl2ZXNjcmlwdC1uZ3gtc2hhZG93LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxtRkFBYyxjQUFjLENBQUM7QUFFN0IsT0FBTyxFQUFDLHFCQUFxQixJQUFJLEVBQUUsRUFBQyxNQUFNLCtDQUErQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBHZW5lcmF0ZWQgYnVuZGxlIGluZGV4LiBEbyBub3QgZWRpdC5cbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL3B1YmxpY19hcGknO1xuXG5leHBvcnQge05hdGl2ZVNoYWRvd0RpcmVjdGl2ZSBhcyDJtWF9IGZyb20gJy4vbmF0aXZlc2NyaXB0LW5neC1zaGFkb3cvbmctc2hhZG93LmRpcmVjdGl2ZSc7Il19