/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { NativeShadowDirective as ɵa } from './nativescript-ngx-shadow/ng-shadow.directive';
