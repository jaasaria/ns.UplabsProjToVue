export declare class NgShadowModule {
}
