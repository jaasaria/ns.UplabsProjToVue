var observableModule = require("tns-core-modules/data/observable").Observable;
const topmost = require("ui/frame").topmost;

const viewModel = new observableModule();

let conversations = [
	{ convFriendImg: "~/images/images.jpg", read: "notRead", convFriendName: "John", convText: "ok but why?", convDate: "19:01", seenVisibility: "collapse" },
	{ convFriendImg: "~/images/large.jpg", read: "read", convFriendName: "Christine", convText: "Okay", convDate: "18:43", seenVisibility: "collapse" },
	{ convFriendImg: "~/images/download_(1).jpg", read: "read", convFriendName: "Katty", convText: "You: Sorry I Can't", convDate: "18:21", seenVisibility: "visible" },

]

let drawer;


let convsViewModel = (page) => {
	viewModel.set('drawerTrigger', '');
	viewModel.set('convColor', "#1aa3ff");

	viewModel.set('conversations', conversations);

	drawer = page.getViewById("sideDrawer");
	return viewModel;
}

viewModel.profileTap = (args) => {
	topmost().navigate({ moduleName: "profile/profile", clearHistory: true, animated: false })
}

viewModel.homeTap = (args) => {
	topmost().navigate({ moduleName: "home/home-page", clearHistory: true, animated: false })
}



viewModel.toggleDrawer = (args) => {
	drawer.toggleDrawerState();
	if (viewModel.get('drawerTrigger') === '') {
		viewModel.set('drawerTrigger', '');
	}
	else {
		viewModel.set('drawerTrigger', '');
	}

}

viewModel.onDrawerOpened = (args) => {
	viewModel.set('drawerTrigger', '');
}

viewModel.onDrawerClosed = (args) => {
	viewModel.set('drawerTrigger', '');
}

exports.convsViewModel = convsViewModel;