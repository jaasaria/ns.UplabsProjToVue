var frameModule = require("ui/frame");
var convsViewModel = require("./convs-view-model").convsViewModel;
var color_1 = require("color");

function pageLoaded(args) {
	var page = args.object;

	var color = new color_1.Color("#fff");
	var textField = page.getViewById("searchField");
	if (page.android) {
		textField.android.setHintTextColor(color.android);
	}
	else if (page.ios) {
		var placeholder = textField.ios.valueForKey("placeholderLabel");
		placeholder.textColor = color.ios;
	}

	page.bindingContext = convsViewModel(page);
}

exports.pageLoaded = pageLoaded;
