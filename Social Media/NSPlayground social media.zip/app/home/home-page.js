var color_1 = require("color");
var frameModule = require("tns-core-modules/ui/frame");
var homeViewModel = require("./home-view-model").HomeViewModel;

function pageLoaded(args) {

  var page = args.object;

 
  var color = new color_1.Color("#fff");
  var textField = page.getViewById("searchField");
  if (page.android) {
    textField.android.setHintTextColor(color.android);
  }
  else if (page.ios) {
    var placeholder = textField.ios.valueForKey("placeholderLabel");
    placeholder.textColor = color.ios;
  }
  
  page.bindingContext = homeViewModel(page);
}


exports.pageLoaded = pageLoaded;
