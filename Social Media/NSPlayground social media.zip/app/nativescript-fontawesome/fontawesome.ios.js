"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fontawesome_common_1 = require("./fontawesome.common");
var Fontawesome = (function (_super) {
    __extends(Fontawesome, _super);
    function Fontawesome() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Fontawesome;
}(fontawesome_common_1.Common));
exports.Fontawesome = Fontawesome;
//# sourceMappingURL=fontawesome.ios.js.map