export declare class Common {
    static init(): void;
}
