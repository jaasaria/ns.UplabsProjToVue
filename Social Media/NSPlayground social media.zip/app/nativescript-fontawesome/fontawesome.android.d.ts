import { Common } from './fontawesome.common';
export declare class Fontawesome extends Common {
}
