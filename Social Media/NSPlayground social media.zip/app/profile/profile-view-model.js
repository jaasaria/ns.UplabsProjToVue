var observableModule = require("tns-core-modules/data/observable").Observable;
const topmost = require("ui/frame").topmost;

const viewModel = new observableModule();

let homePosts = [
	{ authorImg: "~/images/Sebastian.jpg", autorName: "Sebastian", color: "#747474", date: "Today at 13:45", title: "Thank you Guys !", postImg: "~/images/bday.png", likes: "30", comments: "14", reposts: "8" },
	{ authorImg: "~/images/large.jpg", autorName: "Cristine", color: "#E15050", date: "Today at 16:21", title: "I Love California 🌞", postImg: "~/images/cali.png", likes: "150", comments: "21", reposts: "11" },
]

let conversations = [
	{ convFriendImg: "~/images/large.jpg", convFriendName: "Christine", convText: "Okay", convDate: "18:43", seenVisibility: "collapse" },
	{ convFriendImg: "~/images/download_(1).jpg", convFriendName: "Katty", convText: "You: Sorry I Can't", convDate: "18:21", seenVisibility: "visible" },
]

let drawer;

let profileViewModel = (page) => {
	viewModel.set('drawerTrigger', '');
	viewModel.set('profileColor', "#1aa3ff");

	drawer = page.getViewById("sideDrawer");
	return viewModel;
}

viewModel.homeTap = (args) => {
	topmost().navigate({ moduleName: "home/home-page", clearHistory: true, animated: false })
}

viewModel.conversationsTap = (args) => {
	topmost().navigate({ moduleName: "convs/convs", clearHistory: true, animated: false })
}



viewModel.toggleDrawer = (args) => {
	drawer.toggleDrawerState();
	if (viewModel.get('drawerTrigger') === '') {
		viewModel.set('drawerTrigger', '');
	}
	else {
		viewModel.set('drawerTrigger', '');
	}

}

viewModel.onDrawerOpened = (args) => {
	viewModel.set('drawerTrigger', '');
}

viewModel.onDrawerClosed = (args) => {
	viewModel.set('drawerTrigger', '');
}

exports.profileViewModel = profileViewModel;


